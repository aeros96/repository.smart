import xbmcaddon

addon_id = xbmcaddon.Addon().getAddonInfo('id')

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/aeros96/repository.smart/main/aeros/smartnetwizard21.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/aeros96/repository.smart/main/aeros/notify21.txt'

'''#####-----Excludes-----#####'''
excludes  = [addon_id, 'packages', 'backups', 'plugin.video.whatever']
