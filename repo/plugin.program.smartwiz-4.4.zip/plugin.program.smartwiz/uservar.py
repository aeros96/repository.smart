import xbmcaddon

addon_id = xbmcaddon.Addon().getAddonInfo('id')

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/aeros96/repository.smart/main/aeros/smartwizard44.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/aeros96/repository.smart/main/aeros/notify33.txt'

'''#####-----Excludes-----#####'''
excludes  = [addon_id, 'packages', 'backups', 'plugin.video.whatever']
