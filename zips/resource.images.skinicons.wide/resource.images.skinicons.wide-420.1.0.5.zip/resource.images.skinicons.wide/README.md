# resource.images.skinicons.wide
